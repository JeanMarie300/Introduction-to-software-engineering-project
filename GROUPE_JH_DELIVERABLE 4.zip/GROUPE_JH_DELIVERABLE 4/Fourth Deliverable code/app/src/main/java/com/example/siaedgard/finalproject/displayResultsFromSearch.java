package com.example.siaedgard.finalproject;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class displayResultsFromSearch extends AppCompatActivity
{
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        //check the layout search_by_rating.xml for activity on this page
    }

}

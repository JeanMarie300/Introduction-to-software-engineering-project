# Introduction-To-Software-Engineering-Project

Team Leader: Jean-Marie N'Dah    (jndah045@uottawa.ca) 7350840  (SEG2105 A)
                        Hassan Mokdad   (mmokd046@uottawa.ca) 7339241 (SEG2105 A)
                       Alara Özbir    (aozbi043@uottawa.ca) 7621638 (SEG2505)
                        Ciceron Ludny (lcice008@uottawa.ca) 7962403 (SEG2505)
                        Edgard Sia (esia080@uottawa.ca) 7952575 (SEG2505)

Github Repository Link : https://github.com/JeanMarie300/Introduction-to-software-engineering-project


Account created login informations: 

Admin 
	username:admin
	password:admin
Home owner
	username:HomeOwner
	password:Homeowner
Service Provider
	username: ServiceProvider
	password:serviceprovider

Testing home owner functionnality instructions :

1. If it is desired to book an appointment with a service provider:

	- Login as a service provider
	-Insert the availabilities that you are going to input with the home owner
	-log out 
	-Login as a home owner and try to book a service using the three criteria. 

These instructions are important to follow, since a booking can only occur if the the service provider is available.
for the selected timeslot. 

